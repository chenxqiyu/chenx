declare const gradioApp: () => Document | ShadowRoot
declare const switch_to_txt2img: () => void
declare const switch_to_img2img: () => void
declare const onUiLoaded: (callback: () => void) => void
declare const onUiUpdate: (callback: () => void) => void
declare const onUiTabChange: (callback: () => void) => void
