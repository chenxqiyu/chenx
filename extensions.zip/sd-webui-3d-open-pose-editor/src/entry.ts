import { Main } from './environments/online/main'

Main()
