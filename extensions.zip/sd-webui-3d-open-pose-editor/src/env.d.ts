interface ImportMetaEnv {
    readonly VITE_IS_ONLINE?: boolean
}
